package com.example;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;

public class MainController {

    @FXML
    private Label nameLabel;

    private MainApp mainApp;
    private Card card1;
    private Card card2;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    public void setName(String name) {
        nameLabel.setText("Jugador: " + name);
    }

    public void setCard1(Card card) {
        card1 = card;
    }

    public void setCard2(Card card) {
        card2 = card;
    }

    public void pauseAndHideCards() {
        card1.hide();
        card2.hide();
        card1.setDisable(false);
        card2.setDisable(false);
        card1 = null;
        card2 = null;
    }

    public void checkPair() {
        if (card1.getValue().equals(card2.getValue())) {
            card1.setMatched(true);
            card2.setMatched(true);
            card1.setDisable(true);
            card2.setDisable(true);
            card1 = null;
            card2 = null;

            if (checkAllCardsMatched()) {
                Platform.runLater(() -> {
                    showAlert("¡Felicidades!", "Has encontrado todas las parejas.");
                    mainApp.restartGame();
                });
            }
        } else {
            MainApp.pauseAndHideCards(card1, null);
        }
    }

    private boolean checkAllCardsMatched() {
        // Comprobar si todas las cartas se han emparejado
        // Recorre las cartas del GridPane y verifica si alguna no está emparejada
        // Si encuentra una carta no emparejada, retorna false; de lo contrario, retorna true
        return true; // Implementa tu lógica aquí
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
