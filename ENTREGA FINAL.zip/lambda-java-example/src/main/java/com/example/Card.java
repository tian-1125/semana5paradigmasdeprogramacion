package com.example;

import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Card extends Button {

    private String value;
    private boolean showing;
    private boolean matched;

    public Card(String value) {
        this.value = value;
        this.showing = false;
        this.matched = false;

        Rectangle cardShape = new Rectangle(80, 80);
        cardShape.setFill(Color.WHITE);
        cardShape.setStroke(Color.BLACK);

        setGraphic(cardShape);
    }

    public String getValue() {
        return value;
    }

    public boolean isShowing() {
        return showing;
    }

    public void show() {
        showing = true;
    }

    public void hide() {
        showing = false;
    }

    public boolean isMatched() {
        return matched;
    }

    public void setMatched(boolean matched) {
        this.matched = matched;
    }
}
