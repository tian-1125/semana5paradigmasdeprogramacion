package com.example;
/* Entrega final Escenario 7
 * Juego de parejas
 * Participantes
 * Jean Sebastian Moreno Hernandez
 * José Eucardo Montaño Valencia
 * José Augusto Dimate Martinez
 * Moncayo Salazar Saul Eliud
 */
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainApp.class, args);
    }
}